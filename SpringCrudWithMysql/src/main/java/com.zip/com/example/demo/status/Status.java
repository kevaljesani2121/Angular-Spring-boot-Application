package com.example.demo.status;

public enum Status {
	   SUCCESS,
	    USER_ALREADY_EXISTS,
	    FAILURE
}
