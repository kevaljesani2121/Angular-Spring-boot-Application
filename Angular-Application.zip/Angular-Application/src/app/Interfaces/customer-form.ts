export interface CustomerForm{
  id:number,
  uName:string,
  email:string,
  password:string,
  phoneNo:number,
  birthDate:string,
  address:string,
  city:string
}
