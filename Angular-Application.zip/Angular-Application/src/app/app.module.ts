import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginDashbordComponent } from './LoginUser/login-dashbord/login-dashbord.component';
// import { HeaderComponent } from './header/header.component';
import { RegisterCustomerComponent } from './register-customer/register-customer.component';
import { CustomerDashbordComponent } from './customer-dashbord/customer-dashbord.component';
// import { AlertModule } from 'ngx-bootstrap';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { NavbarComponent } from './navbar/navbar.component';
import { FormsModule } from '@angular/forms';
import { SignupCustomerComponent } from './LoginUser/signup-customer/signup-customer.component';
import { DataTablesModule } from 'angular-datatables';
import { NgxPaginationModule } from 'ngx-pagination';
import { FooterComponent } from './footer/footer.component';
import { CommonInterceptor } from './common.interceptor';
import { CustomerForm } from './Constances/Customer-Form';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatSidenavModule} from '@angular/material/sidenav';
import {MatButtonModule} from '@angular/material/button';
import {MatIconModule} from '@angular/material/icon';
import {MatDividerModule} from '@angular/material/divider';
import { LeftNavagationComponent } from './left-navagation/left-navagation.component';
import { RunAnalysisComponent } from './test/run-analysis/run-analysis.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginDashbordComponent,
    RegisterCustomerComponent,
    CustomerDashbordComponent,
    NavbarComponent,
    SignupCustomerComponent,
    FooterComponent,
    LeftNavagationComponent,
    RunAnalysisComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule,
    NgxPaginationModule,
    DataTablesModule,
    BrowserAnimationsModule,
    MatIconModule,
    MatSidenavModule,
    MatToolbarModule,
    MatButtonModule,
    MatDividerModule
  ],
  providers: [
    {provide:HTTP_INTERCEPTORS,useClass:CommonInterceptor,multi:true }
    ,
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
