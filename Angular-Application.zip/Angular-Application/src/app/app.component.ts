import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {AuthenticationGuard} from '../app/Auth/authentication.guard';



@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
}) 


export class AppComponent implements OnInit{
  title = 'Angular-Application';

  constructor( autheService:AuthenticationGuard,router:Router){
 
    if(autheService.getAuthenction()){
      router.navigate(['customerDashbord'])
    }
  }

  ngOnInit(){

    // localStorage.setItem("id","1001");
  }

  ngOnDestroy(){
    localStorage.removeItem("User");
  }
 
  getAuthenction():boolean{
    if(localStorage.getItem("User")){
      return true;
    }else{
      return false;
    }
  }
}
