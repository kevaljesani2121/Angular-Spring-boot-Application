import { HttpClient } from '@angular/common/http';
import { Injectable, OnInit } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
// import { map } from 'jquery';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class AuthenticationGuard implements CanActivate ,OnInit{

  constructor(private _http:HttpClient,private routes:Router){

  }
  ngOnInit(): void {
   
    
  }


  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot)
  :Observable<boolean>  |boolean{

    // let logindata=localStorage.getItem("User");
    // if (logindata!==null) {
    //   return true;
    // } else {
    //   // this._router.navigate([RouterLinkEnum.USER_LOGIN]);
    //   return false;
    // }
    if (localStorage.getItem('User')) {
      //   // logged in so return true
        // if(localStorage.getItem('User')!==null){
        // this.routes.navigate(['/customerDashbord'], { queryParams: { returnUrl: state.url }});
      // }
        return true;
    }

    // not logged in so redirect to login page with the return url
    this.routes.navigate(['/login'], { queryParams: { returnUrl: state.url }});
    return false;
    // return true;
  }
  

  // autoLogin(){
  //   let userdata :{email:string;password:string} = JSON.parse(localStorage.getItem("User"));

  //   if(!userdata){
  //     return;
  //   }
  // }

logout() {
    // remove user from local storage to log user out
    localStorage.removeItem('User');
}


  getAuthenction(){
    
    return localStorage.getItem("User");
    // var logindata= localStorage.getItem("User");
    // if(localStorage.getItem("User")===null){
    //   // this.routes.navigate(['/login']);
    //   return logindata;
    // }else{
    //   return logindata;
    //   // this.routes.navigate([['/customerDashbord']]);
    // }
  }
}
