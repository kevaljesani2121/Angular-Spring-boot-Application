import { NgModule, OnInit } from '@angular/core';
import { ActivatedRoute, Router, RouterModule, Routes } from '@angular/router';
import { AuthenticationGuard } from './Auth/authentication.guard';
import { CustomerDashbordComponent } from './customer-dashbord/customer-dashbord.component';
import { LeftNavagationComponent } from './left-navagation/left-navagation.component';
import { LoginDashbordComponent } from './LoginUser/login-dashbord/login-dashbord.component';
import { SignupCustomerComponent } from './LoginUser/signup-customer/signup-customer.component';
import {  RegisterCustomerComponent } from './register-customer/register-customer.component';
// import { RunAnylysis } from './test/run-analysis';
import { RunAnalysisComponent } from './test/run-analysis/run-analysis.component';

const routes: Routes = [
  {path:"",redirectTo:'login', pathMatch:'full'},
  { path:"login",component:LoginDashbordComponent },
  {path:"customerDashbord",canActivate:[AuthenticationGuard], component:CustomerDashbordComponent},
  {path:"addcustomer",canActivate:[AuthenticationGuard],component:RegisterCustomerComponent},
  {path:"add",component:SignupCustomerComponent},
  {path:"editcustomer/:id",canActivate:[AuthenticationGuard],component:RegisterCustomerComponent},
  {path:"run-anylysis",component:RunAnalysisComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {


 
}

