import { Injectable ,Injector} from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor
} from '@angular/common/http';
import { Observable } from 'rxjs';
import {AuthenticationGuard} from '../app/Auth/authentication.guard'
import { Router } from '@angular/router';



@Injectable()
export class CommonInterceptor implements HttpInterceptor {

  constructor(private injector:Injector,private router:Router) {}

  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    // let getdata=localStorage.getItem("User");

    // if(getdata!==null)
    // {
    //      this.router.navigate(['/customerDashbord']);                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        
    // }else{
    //   this.router.navigate(['/login']);
    // }



    
    let authenction=this.injector.get(AuthenticationGuard)
    let useAuthenction=request.clone({
      setHeaders:{
        Authenction:`Users ${authenction.getAuthenction()}`
       
      }
     
    })
    // if(this.getCookie("User")){
    // this.router.navigate(['/customerDaskbord']);
    // }else{
    //   this.router.navigate(['/login'])
    // }
    return next.handle(useAuthenction)
    
  }

  // setCookie(cname:any, cvalue:any, exdays:any) {
  //   var d = new Date();
  //   d.setTime(d.getTime() + (exdays*24*60*60*1000));
  //   var expires = "expires="+ d.toUTCString();
  //   document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
  // }
  

  // getCookie(cname:any) {
  //   var name = cname + "=";
  //   var decodedCookie = decodeURIComponent(document.cookie);
  //   var ca = decodedCookie.split(';');
  //   for(var i = 0; i <ca.length; i++) {
  //     var c = ca[i];
  //     while (c.charAt(0) == ' ') {
  //       c = c.substring(1);
  //     }
  //     if (c.indexOf(name) == 0) {
  //       return c.substring(name.length, c.length);
  //     }
  //   }
  //   return "";
  // }
  

}
