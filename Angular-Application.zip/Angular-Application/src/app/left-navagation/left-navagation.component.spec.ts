import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LeftNavagationComponent } from './left-navagation.component';

describe('LeftNavagationComponent', () => {
  let component: LeftNavagationComponent;
  let fixture: ComponentFixture<LeftNavagationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LeftNavagationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LeftNavagationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
