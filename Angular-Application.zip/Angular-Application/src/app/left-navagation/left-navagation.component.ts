import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-left-navagation',
  templateUrl: './left-navagation.component.html',
  styleUrls: ['./left-navagation.component.scss']
})
export class LeftNavagationComponent implements OnInit {

  constructor(private activateRoute:ActivatedRoute) { }

  ngOnInit(): void {
  }

  id :any=null;


  getValueInsideUrl(){
    this.id =this.activateRoute.snapshot.paramMap.get('id');
  }
//  function
   
 logOutUser(){
   return localStorage.removeItem("User");
  }
}
