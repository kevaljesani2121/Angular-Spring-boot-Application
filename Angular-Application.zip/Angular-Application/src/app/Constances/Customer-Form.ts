export class CustomerForm{
    id='';
    uName="";
    email="";
    password="";
    phoneNumber='';
    birthDate="";
    address="";
    city="";

}

