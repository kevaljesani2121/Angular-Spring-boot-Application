export class SignupCustomer{
    name="";
    email="";
    password="";
    phoneNumber='';
    birthDate="";
    address="";

}