import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Customer } from '../customer-dashbord/Customer';



@Injectable({
  providedIn: 'root'
})
export class SignUpService {

  constructor(private http:HttpClient) { }

  // url ="http://localhost:3000/user";
  // url="http:localhost:8080/customer/add";

  signupCustomer(customer:Customer):Observable<any>{
    return this.http.post("http://localhost:8080/student/add",customer,{responseType :"text" as "json"});
  }

}
