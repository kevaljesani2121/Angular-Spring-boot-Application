import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Customer } from '../customer-dashbord/Customer';

@Injectable({
  providedIn: 'root'
})
export class RestServiceService {

  constructor(private _http:HttpClient) { }

  // url ="http://localhost:3000/user";
  url="http:localhost:8080/student"

  getUsers(){
    return this._http.get<Customer[]>(this.url+"/getall");
  }
}
