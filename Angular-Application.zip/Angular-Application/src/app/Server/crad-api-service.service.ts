import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Customer } from '../customer-dashbord/Customer';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CRADApiServiceService {

  // url ="http://localhost:3000/user";
 url="http://localhost:8080/student";
  constructor(private _http:HttpClient) { }


  getAllCustomer() :Observable<Customer[]>{
    return this._http.get<Customer[]>(this.url+"/getall/");
  }

    submit(data:any){
      return this._http.put<any>(this.url,data).pipe(map((res:any)=>{
        return res;
      }))
    }
    

  
    getUsers(){
      return this._http.get<Customer[]>(this.url+"/getall");
    }  


  addCustomer(data:any) :Observable<Customer []>{
    return this._http.post<Customer []>(this.url+"/add",data,{responseType :"text" as "json"});
  }


  editCustomer(data:any,id:any):Observable<Customer []>{
    return this._http.put<Customer []>(this.url+"/update"+"/"+id,data);    
  }

  deleteCustomer(user:any,id:any):Observable<Customer []>{                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           
    return this._http.delete<any>(this.url+"/delete"+"/"+id+user);
  } 
  
  getCustomerById(id:any){
      return this._http.get<any>(this.url+"/get"+"/"+id);
  }                                                         

}
