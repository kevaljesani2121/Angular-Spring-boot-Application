import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Customer } from '../customer-dashbord/Customer';

@Injectable({
  providedIn: 'root'
})
export class LoginServiceService {

  constructor(private http: HttpClient) { }

  public url = "http://localhost:8080/student/login";

 


  loginUserDetails(user: Customer): Observable<any> {
    //  return this.http.get(`${this.url}`);

    // if(this.getToken()!=null){
    // return this.router.navigate(["/Customer"]);
    // }
    // else{
    return this.http.post<Customer[]>(this.url, user,{responseType :"text" as "json"});
    // }

  }

  loginUser(user: any) {
    localStorage.setItem("User", user);
    return true;
  }


  isLogin() {
    let loginuser = localStorage.getItem("User");
    if (loginuser == undefined || loginuser === "" || loginuser == null) {
      return false;
    } else {
      return true;
    }
  }

  logoutUser() {
    localStorage.removeItem("User");
    return true;
  }

  getToken() {
    return localStorage.getItem("User");
  }


}


