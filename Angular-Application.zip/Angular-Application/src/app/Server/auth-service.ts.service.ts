import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService{

  constructor() { }

  


  private saveAuthData(token: string, expirationDate: Date) {  
     localStorage.setItem('token', token); 
     localStorage.setItem('expiration',expirationDate.toISOString());   
  }  
  private clearAuthData() {  
    localStorage.removeItem("token");  
    localStorage.removeItem("expiration");  
  }  
}
