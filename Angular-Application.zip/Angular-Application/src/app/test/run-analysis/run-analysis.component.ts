import { Component, OnInit, ViewChild } from '@angular/core';
// import { NgbModalConfig, NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-run-analysis',
  templateUrl: './run-analysis.component.html',
  styleUrls: ['./run-analysis.component.scss']

  // providers: [NgbModalConfig, NgbModal]
})
export class RunAnalysisComponent implements OnInit {
  
  @ViewChild('pageModal') pageModal: any;
  public pageNo: number = 1;
  public open: boolean = false;

  masterSelected:boolean;
  checklist:any;
  checkedList:any;
  isDisabled : boolean=true;
  constructor(){
      this.masterSelected = false;
      this.checklist = [
        {id:1,value:'Elenor Anderson',isSelected:false},
        {id:2,value:'Caden Kunze',isSelected:true},
        {id:3,value:'Ms. Hortense Zulauf',isSelected:true},
        {id:4,value:'Grady Reichert',isSelected:false},
        {id:5,value:'Dejon Olson',isSelected:false},
        {id:6,value:'Jamir Pfannerstill',isSelected:false},
        {id:7,value:'Aracely Renner DVM',isSelected:false},
        {id:8,value:'Genoveva Luettgen',isSelected:false}
      ];
      this.getCheckedItemList();
  }

  checkUncheckAll() {
    for (var i = 0; i < this.checklist.length; i++) {
      this.checklist[i].isSelected = this.masterSelected;
    }
    this.getCheckedItemList();
  }

  // Check All Checkbox Checked
  isAllSelected() {
    this.masterSelected = this.checklist.every(function(item:any) {
        return item.isSelected == true;
      })
    this.getCheckedItemList();
  }


  // Get List of Checked Items
  getCheckedItemList(){
    this.checkedList = [];
    for (var i = 0; i < this.checklist.length; i++) {

      if(this.checklist[i].isSelected){
        console.log(this.checklist[i])
        this.checkedList.push(this.checklist[i]);
      }
     
      // console.log((this.checklist[i].isSelected));
    }
    if(this.checkedList.length>1){
      this.isDisabled=true;
      // alert("at least on is check")

    }
    this.checkedList = JSON.stringify(this.checkedList);
  }

  
  checkboxesDataList = [
    {
      id: 'C001',
      label: 'Photography',
      isChecked: true
    },
    {
      id: 'C002',
      label: 'Writing',
      isChecked: true
    },
    {
      id: 'C003',
      label: 'Painting',
      isChecked: true
    },
    {
      id: 'C004',
      label: 'Knitting',
      isChecked: false
    },
    {
      id: 'C004',
      label: 'Dancing',
      isChecked: false
    },
    {
      id: 'C005',
      label: 'Gardening',
      isChecked: true
    },
    {
      id: 'C006',
      label: 'Drawing',
      isChecked: true
    },
    {
      id: 'C007',
      label: 'Gyming',
      isChecked: false
    },
    {
      id: 'C008',
      label: 'Cooking',
      isChecked: true
    },
    {
      id: 'C009',
      label: 'Scrapbooking',
      isChecked: false
    },
    {
      id: 'C010',
      label: 'Origami',
      isChecked: false
    }
  ]
  selectedItemsList: { id: string; label: string; isChecked: boolean; }[] = [];

  fetchSelectedItems() {
    this.selectedItemsList = this.checkboxesDataList.filter((value, index) => {
      return value.isChecked
    });
  }

  changeSelection() {
    this.fetchSelectedItems()
  }



  // checklist:any;
  // checkedList:any;
  checked=true;
  public state = {
    details1:{
      
      Detail_for_WD_RM371: [
        {
          value: 'Update ID',
          label:['WD_RM9354']
         
        },
        {
          value:"Release Version",
          label:['2022R1']
        },
        {
          value:"What's New",
          label:['Hide Workday-Delivered Report Task and Web Services - Workday 2022 Release 1 - Hide Workday-Delivered Reports (Preview only)']
        },
        {
          value:"Functional Area",
          label:['Reporting and Analytics']
        }
        , {
          value:"Setup Effort",
          label:['Setup Required']
        },
        {
         
          value:"Web Services",
          label:['Get Hide Workday Delivered Report,Put Get Hide Workday Delivered Report']
        },
        {
          value:"Jira Number",
          label:['Setup Required']
        },
        {
          value:"Feature",
          label:["Hide or Require Optional Fields for Employee Contracts"]
        },
        {
          value:"Feature Description",
          label:["With this release, you can now hide or require employee contract fields by country and role, giving you more control and flexibility over what users see in employee contract tasks."]
        },
        {
          value:"New Functionality Title",
          label:["Employee Contract Functional Area"]
        },
        {
          value:"New Functionality Description",
          label:["We deliver a new Employee Contract functional area that you can configure using the Configure Optional Fields task to hide or require these fields on tasks that use the Manage Employee Contract business process: • Contract Attachments • Contract Description • Contract End Date • Contract ID • Contract Reason • Contract Review • Contract Type • Date Employee Signed • Date Employer Signed • Maximum Weekly Hours • Minimum Weekly Hours"]
        },
        {
          value:"Tentative Production Date",
          label:["03/12/2022"]
        },
        {
          value:"Preview Date",
          label:["10/22/2021"]
        },
        {
          value:"Security Domain",
          label:["Employee Contract"]
        },
        {
          value:"Domain Groups",
          label:["• Staffing"]
        },
        
      ]
    },
    Matching_Criteria:{
      list2:[
       
          {
            value: 'Key',
            label: 'value'
           
          },
          {
            value:"Functional Area",
            label: ['Academic Advising',
            'Academic Faculty',
            'Academic Foundation',
            'Admissions',
            'Adoption',
            'Advanced Compensation',
            'Banking and Settlement',
            'Benchmarking',
            'Benefits',
            'Budgets',
            'Campus Engagement',
            'CAN Payroll (out of scope)',
            'Cash Management',
            'Common Financial Management',
            'Contact Information',
            'Core Compensation',
            'Core Payroll',
            'Customers',
            'Endowment Accounting',
            'Expenses',
            'Financial Accounting',
            'Financial Aid',
            'FRA Payroll (out of scope)',
            'Grants Management',
            'Headcount Planning',
            'Headcount Plans',
            'Headcount Plans (HCM)',
            'Implementation',
            'Integration',
            'Inventory',
            'Jobs & Positions',
            'Learning Core',
            'Onboarding',
            'Organizations and Roles (out of scope)',
            'Payroll Interface',
            'Performance and Goals',
            'Personal Data',
            'Planning',
            'Pre-Hire Process',
            'Procurement',
            'Project Billing',
            'Projects',
            'Student Financials',
            'Student Records',
            'Student Recruiting',
            'Time Off and Leave',
            'Customer Central (out of scope)',
            'People Experience (out of scope)',
            'Public Data (out of scope)',
            'Scheduling (out of scope)',
            'Workday Development (out of scope)',
            'Audit, Risk and Control',
            'Business Process',
            'Cloud Platform (WCP)',
            'Data Migration',
            'Implementation Tools',
            'Mobile',
            'Organizations (out of scope)',
            'Prism Analytics (out of scope)',
            'Reporting and Analytics',
            'Security',
            'System Administration',
            'Duplicate Management',
            'Student Core',
            'Adaptive Planning',
            'Performance Enablement (out of scope)',
            'Workday Scheduling (out of scope)']
          },
          {
            value:"Business Objects",
            label:['Absence Balance']
          },
          {
            value:"Data Source",
            label:['Benchmark Values']
          },
          {
            value:"Business Processes Type",
            label:['Termination']
          },
          {
            value:"Security Domains",
            label:['Workday Usage Metrics',
            'Academic Unit Hierarchies: Directory',
            'Ability to Create Only Temporary Reports',
            'Self-Service: Student Financials',
            'Benchmark Values',
            'Reports: 1098-T']
          },
          {
            value:"WDAY Delivered Fields",
            label:['Content Item Grade',
            '# of Additional Passengers']
          },
          {
            value:"Integrations Templates",
            label:['Enterprise Interface Builder']
          },
          {
            value:"Reference Types",
            label:['Absence_Balance_ID']
          },
          {
            value:"Task Lists",
            label:['# of Master Data Records at Month-End',
            '1098-T for Printing',
            '1098-T Audit Report']
          },
          {
            value:"Web Services",
            label:['Human Resources (Public)',
            'Compensation (Public)']
          },
          {
            value:"Web Service Operations",
            label:['Add Academic Appointment',
            'Add Stock Grant']
          },
          {
            value:"Standard Reports & Tasks",
            label:['1095-C Eligible Employees by State or Region',
            '1099 MISC Report',
            'View Custom List']
          },
      
      ]
    },
    Recommendation_Details:{
      list3:[
        {
          value:"Recommendation Title:",
          label:["Recommendation Title 2"]
        },
        {
          value:"Recommendation Description:",
          label:['No needed']
        },
        {
          value:"Complexity",
          label:['High (Has broad impacts and/or requires significant design)']
        },
        {
          value:"Effort Required",
          label:['High (>=40 Hours)']
        },
        {
          value:"Highly Recommended?",
          label:['Yes']
        },
        {
          value:"Testing Required?",
          label:['Yes']
        },
        {
          value:"Cross-Workstream Impact?",
          label:['Yes']
        },
        {
          value:"Impacted Groups",
          label:['All end users , HR Admin , Managers']
        },
        {
          value:"Overall Impact Flag",
          label:['No']
        },
        {
          value:"Training Material Impact?",
          label:['Yes']
        },
        {
          value:"Cross-Workstream",
          label:['Hii']
        }

      ]
    },
    table:{
      task_list:
        [  
          {
           id:"#",
           phase:"Phase",
           desc:"Impact Description",
           depan:"Dependencies" 

          },
          {
            id:"1",
            phase:["analysis"],
            desc:["test"],
            depan:[""] 
          },{
            id:"2",
            phase:["test"],
            desc:["March test plan"],
            depan:["Dependencies"] 
          }
      ]
      
    }
  }

 

  

  ngOnInit(): void {
  }


  // fatchDataFromModules(){
  //   console.log("test");
  // }
  
  // open(content:any) {
  //   this.modalService.open(content, {size: 'lg', windowClass: 'modal-xl'});
  //   }

  public showPageModal() {
    // this.pageNo = no;
    this.pageModal.show();
  }

  public hidePageModal() {
    this.pageModal.hide();
    // this.pageNo = 1;
  }
}
