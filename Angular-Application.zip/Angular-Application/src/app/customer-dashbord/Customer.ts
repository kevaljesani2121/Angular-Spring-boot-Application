export class Customer{
    id:number;
    uName:string;
    email:string;
    password:string;
    phoneNumber:string;
    birthDate:string;
    address:string;
    city:string


    constructor(id :number,uName:string,email:string,password:string,phoneNumber:string,
        birthDate:string,address:string,city:string){
        this.id=id;
        this.uName=uName;
        this.email=email;
        this.password=password;
        this.phoneNumber=phoneNumber;
        this.birthDate=birthDate;
        this.address=address;
        this.city=city;
    }
}