import { Component, DoCheck, OnDestroy, OnInit } from '@angular/core';
import user from '../Server/db.json';
import { HttpClientModule } from '@angular/common/http';
import { RestServiceService } from '../Server/rest-service.service';
import { Customer } from '../customer-dashbord/Customer';
import { CustomerForm } from '../Constances/Customer-Form';
import { CRADApiServiceService } from '../Server/crad-api-service.service';
import { ActivatedRoute, Router } from '@angular/router';
import { DataTableDirective, DataTablesModule } from 'angular-datatables';
import { BehaviorSubject, Observable } from 'rxjs';
import { switchMap } from 'rxjs/operators';
import { data } from 'jquery';

interface USERS {
  id: Number;
  uName: String;
  email: String;
  phoneNumber: string;
  password: string;
  birthDate: string;
  address: string;
  city: string;
}



@Component({
  selector: 'app-customer-dashbord',
  templateUrl: './customer-dashbord.component.html',
  styleUrls: ['./customer-dashbord.component.scss']
})


export class CustomerDashbordComponent implements OnInit {

  columns = ["Customer-Id", "Name", "Email", "phoneNumber", "birthDate", "city"];
  index = ["id", "uName", "email", "password", "birthDate", "phoneNumber", "address", "city"];

  id = "";
  customerName = "";
  email = "";
  password = "";
  birthDate = "";
  phoneNumber = "";
  address = "";
  city = "";


  dtOpations: DataTables.Settings = {};
 
  Users: USERS[] = [];


  refreshDatatable$ = new BehaviorSubject<boolean>(true);
  dtTrigger: any;
  dtElement: any;

  constructor(private _restReq: RestServiceService,
    private _requestRegisterForm: CRADApiServiceService,
    private activateRoute: ActivatedRoute,
    private routes: Router) {

  }

  data: any;
  fetchTableData() {
   
    // this.getAllCustomer();
    this._requestRegisterForm.getAllCustomer().subscribe(data =>{
      this.data = data;
    
  });
  }


  ngOnInit(): void {
    // this.fetchTableData();
    this.getAllCustomer();

  }

  logOutUser() {
    localStorage.removeItem("User");
  }

  getAllCustomer() {
    this._requestRegisterForm.getUsers().subscribe((response) => {
      this.Users = response;

      setTimeout(()=>{
        $('#datatableexample').DataTable({
          pagingType:"full_numbers",
          lengthMenu:[2,4,6],
          processing:true,
          retrieve:true
        });
      },3);
    },

      (error) => console.log(console.error())
    )}
   
  
 
  deleteCustomers(a: any) {
    if (confirm("are you sure went to delete the use ?")) {
      this._requestRegisterForm.deleteCustomer(a,this.id).subscribe(
        ()=> {
          // if(data.success){
          //   this.fetchTableData();
          // }
          // this.fetchTableData();
          this.routes.navigate(["/customerDashbord"]);
          this.getAllCustomer();
         
        })


    }

  }

  myfun(){
    this.routes.navigate(["/run-anylysis"]);
  }

}

