import { Route } from '@angular/compiler/src/core';
import { Component, OnInit } from '@angular/core';
import {FormBuilder,FormGroup,FormControl, Validators} from '@angular/forms';
import { ActivatedRoute, Router} from '@angular/router';
// import {RouterModule} from '@angular/router'
import { SignUpService } from 'src/app/Server/sign-up.service';
import {SignupCustomer} from '../../Constances/SignupCustomer'


@Component({
  selector: 'app-signup-customer',
  templateUrl: './signup-customer.component.html',
  styleUrls: ['./signup-customer.component.scss']
})
export class SignupCustomerComponent implements OnInit {

  signupCustomer :SignupCustomer=new SignupCustomer();

  constructor(
    private signupRequst:SignUpService,
    private activateRoute:ActivatedRoute,
    private routes:Router) { }

  ngOnInit(): void {
      this.futureDateDisable();
  }
 
    maxDate:any;

   futureDateDisable(){
     var date:any=new Date();
     var todayDate:any= date.getDate();
     var month:any=date.getMonth()+1;
     var year:any=date.getFullYear();

     if(todayDate<10){
      todayDate='0'+todayDate;
     }
     if(month<10){
       month='0'+month;
     }
     this.maxDate=year +"-"+month+"-"+todayDate;
    //  console.log(this.maxDate);
  } 

  signupForm = new FormGroup({
    uName:new FormControl('',[Validators.required,Validators.minLength(3),Validators.maxLength(30)]),
    email: new FormControl('',[Validators.required,Validators.pattern("[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$")]),
    password: new FormControl('',[Validators.required,Validators.pattern("^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$")]),
      phoneNumber: new FormControl('',[Validators.required,Validators.pattern("^[0-9]{10}$")]),
      birthDate: new FormControl('',[Validators.required]),
      address: new FormControl('',[Validators.required,Validators.minLength(3)]),
      city: new FormControl('',[Validators.required,Validators.minLength(3)])
    })
  ;


 
  get getControl(){
    return this.signupForm.controls;
  }


  // setCookie(cname:any, cvalue:any, exdays:any) {
  //   var d = new Date();
  //   d.setTime(d.getTime() + (exdays*24*60*60*1000));
  //   var expires = "expires="+ d.toUTCString();
  //   document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
  // }
  

  // getCookie(cname:any) {
  //   var name = cname + "=";
  //   var decodedCookie = decodeURIComponent(document.cookie);
  //   var ca = decodedCookie.split(';');
  //   for(var i = 0; i <ca.length; i++) {
  //     var c = ca[i];
  //     while (c.charAt(0) == ' ') {
  //       c = c.substring(1);
  //     }
  //     if (c.indexOf(name) == 0) {
  //       return c.substring(name.length, c.length);
  //     }
  //   }
  //   return "";
  // }
  
  submit(){
    this.signupRequst.signupCustomer(this.signupForm.value).subscribe(
      () =>
      {
        console.log(this.signupForm.value);
        alert("Signup is succefuly");
        this.signupForm.reset();
        this.routes.navigate(['/login']);
        // this.setCookie("User","customer",1);

      }
    )
  }

}
