import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { HttpClient, HttpHeaderResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { CustomerDashbordComponent } from '../../customer-dashbord/customer-dashbord.component';
import { AuthenticationGuard } from 'src/app/Auth/authentication.guard';
import { Customer } from 'src/app/customer-dashbord/Customer';
import { LoginServiceService } from 'src/app/Server/login-service.service';



@Component({
  selector: 'app-login-dashbord',
  templateUrl: './login-dashbord.component.html',
  styleUrls: ['./login-dashbord.component.scss']
})
export class LoginDashbordComponent implements OnInit {

  submitted = true;

  public loginForm !: FormGroup;
  // public url="http://localhost:3000/user";
  public url = "http://localhost:8080/customer/login";

  constructor(private formBuilder: FormBuilder, private _http: HttpClient,
    private routerLink: Router, private authtications: AuthenticationGuard,
    private loginService: LoginServiceService) { }

  user: any = {};
  ngOnInit(): void {
    this.loginForm = this.formBuilder.group({
      email: new FormControl('', [Validators.required, Validators.pattern("[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$")]),
      password: new FormControl('', [Validators.required, Validators.pattern("^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$")])

    })


  }


  get getControl() {
    return this.loginForm.controls;
  }

  getToken() {
    return localStorage.getItem("User");
  }


  loginUser() {

    this.loginService.loginUserDetails(this.loginForm.value).subscribe(res => {

      // const user= res.find((a:any)=>{
      {
        var email = this.loginForm.value.email;
        var password = this.loginForm.value.password;
        var user: any = { "email": email, "password": password };
        var json=JSON.parse(res);
        console.log(typeof(json));
        // this.data = res._body;
        // console.log(res.status);
        // return  user;
        // return res.email === this.loginForm.value.email && res.password === this.loginForm.value.password;  
      }            //   }
      //  )
      ;




      // if (user && res==={"message":"user login succefully !","status":"OK"}) {
        if(json.status=="OK"){
        this.user = Object.assign(this.user, this.loginForm.value);
        localStorage.setItem("User", JSON.stringify(this.user));
        alert("user login suucessfuly");
        this.loginForm.reset();
        this.routerLink.navigate(["/customerDashbord"]);
      } else {
        alert("please to check email and password !");
      }

    }, err => {
      alert("some thing went to wrong");
    })
  }

  getData() {
    console.log(localStorage.getItem("formdata"));
  }

  deleteData() {
    localStorage.removeItem('id');
  }


}
