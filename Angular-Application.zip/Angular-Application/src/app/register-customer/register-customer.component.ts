import { Component, OnInit } from '@angular/core';
import {FormGroup,FormBuilder,FormControl,Form, Validators} from '@angular/forms';
import { Customer } from '../customer-dashbord/Customer';
import { CRADApiServiceService } from '../Server/crad-api-service.service';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { CustomerForm } from '../Constances/Customer-Form';
import {SignupCustomerComponent} from '../LoginUser/signup-customer/signup-customer.component'

@Component({
  selector: 'app-register-customer',
  templateUrl: './register-customer.component.html',
  styleUrls: ['./register-customer.component.scss']
})


export class RegisterCustomerComponent implements  OnInit {


  uName="";
  email="";
  password="";
  phoneNumber="";
  birthDate="";
  address="";
  city="";
  
  customer:Customer[] = [];
  customersForm :CustomerForm =new CustomerForm();
  
  customerForm = new FormGroup({
    uName:new FormControl('',[Validators.required,Validators.minLength(3),Validators.maxLength(30)]),
    email: new FormControl('',[Validators.required,Validators.pattern("[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$")]),
    password: new FormControl('',[Validators.required,Validators.pattern("^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$")]),
      phoneNumber: new FormControl('',[Validators.required,Validators.pattern("^[0-9]{10}$")]),
      birthDate: new FormControl('',[Validators.required]),
      address: new FormControl('',[Validators.required,Validators.minLength(3)]),
      city: new FormControl('',[Validators.required,Validators.minLength(3)])
    })
  ;

    constructor(private _reqestForCRADService:CRADApiServiceService,
      private router:Router,private activateRoute:ActivatedRoute) {
      // super();
    }
  maxDate: any;
  

  futureDateDisable(){
    var date:any=new Date();
    var todayDate:any= date.getDate();
    var month:any=date.getMonth()+1;
    var year:any=date.getFullYear();

    if(todayDate<10){
     todayDate='0'+todayDate;
    }
    if(month<10){
      month='0'+month;
    }
    this.maxDate=year +"-"+month+"-"+todayDate;
   //  console.log(this.maxDate);
 } 

     id :any=null;


  ngOnInit() :void{
    this.getValueInsideUrl();
    // console.log("user id"+this.id);
    this.futureDateDisable();
  this.getAllValueForUpdate(); 
      
  }  

 

  get getControl(){
    return this.customerForm.controls;
  }

  getValueInsideUrl(){
    this.id =this.activateRoute.snapshot.paramMap.get('id');
  }

  getAllValueForUpdate(){
    this._reqestForCRADService.getCustomerById(this.id).subscribe(
      (res:any)=>{
        // console.log(res);
     this.customerForm=new FormGroup({
          uName: new FormControl(res['uName']),
          email: new FormControl(res['email']),
          password: new FormControl(res['password']),
          phoneNumber: new FormControl(res['phoneNumber']),
          birthDate: new FormControl(res['birthDate']),
          address: new FormControl(res['address']),
          city: new FormControl(res['city'])
        }) 
      })
  }


  submit():void{

    //  1.  get the data inside the variable. or 2.
      // const data= {
      //   uName:this.uName,
      //   email:this.email,
      //   password:this.password,
      //   phoneNumber:this.phoneNumber,
      //   birthDate:this.birthDate,
      //   address:this.address,
      //   city:this.city
      // }

      // 2.toget the form value useing customerForm.value

    if(this.id ===null){
     this._reqestForCRADService.addCustomer(this.customerForm.value).subscribe(
        () =>
        {
            alert("user insert succesfuly");
            this.customerForm.reset();
            this.router.navigate(['/customerDashbord']);
        }
      )
      }
      else if(this.id!==null){ 
      //  this.futureDateDisable(); 
      this._reqestForCRADService.editCustomer(this.customerForm.value,this.id).subscribe(
        ()=>{
            // console.log(this.customerForm.value);

            this.router.navigate(['/customerDashbord']);
            alert("User update succesfuly")
        }); 


      }
  }

}
