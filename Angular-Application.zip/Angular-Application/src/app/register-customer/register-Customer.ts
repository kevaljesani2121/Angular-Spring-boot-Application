export class RegisterCustomer{
    name:string;
    email:string;
    password:string;
    phoneNo:number;
    birthDate:string;
    address:string;
    city:string;


    constructor(name:string,
        email:string,
        password:string,
        phoneNo:number,
        birthDate:string,
        address:string,
        city:string){
            this.name=name;
            this.email=email;
            this.password=password;
            this.phoneNo=phoneNo;
            this.birthDate=birthDate;
            this.address=address;
            this.city=city
    }
}