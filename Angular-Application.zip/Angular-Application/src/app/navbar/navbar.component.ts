import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';
import { param } from 'jquery';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent implements OnInit {
  url:any;
  constructor(private activateRoute:ActivatedRoute) { }

  ngOnInit(): void { 

    // this.url =this.activateRoute.snapshot.paramMap.get("/");
    // this.url =this.activateRoute.params.subscribe((params:Params)=>
    // {
    //   // if(params.http){
    //     console.log(this.url);
    //   // }
    // })
    // console.log(this.url);


  }
  logOutUser(){
    localStorage.removeItem("User");
  }

  // $scope.getClass = function (path) {
    // return ($location.path().substr(0, path.length) === path) ? 'active' : '';
  // }

  scope:any;
  location:any;
  // $scope.isActive = function (viewLocation:any){
    // var active = (viewLocation === $location.path());
    // return active;
// };
  

}
